copy "%~dp0\undertale.ini" "C:\Users\%USERNAME%\AppData\Local\UNDERTALE"

copy "%~dp0\file0" "C:\Users\%USERNAME%\AppData\Local\UNDERTALE"

